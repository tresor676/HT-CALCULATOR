let currentTab = "base";
let display = document.getElementById("display");
let baseButtons = ["7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+"];
let sciButtons = ["sin(", "cos(", "tan(", "ln(", "log(", "√", "^", "(", ")", "!", "exp(", "asin(", "acos(", "atan(", "π", "DEG↔RAD"];
let angleMode = "DEG";

function switchTab(tab) {
  document.querySelectorAll(".buttons-tab").forEach(el => el.classList.add("hidden"));
  if (tab === "base") {
    document.getElementById("buttons-base").classList.remove("hidden");
  } else if (tab === "scientifique") {
    document.getElementById("buttons-base").classList.remove("hidden");
    document.getElementById("buttons-scientifique").classList.remove("hidden");
  } else if (tab === "parametres") {
    document.getElementById("settings").classList.remove("hidden");
  }
  currentTab = tab;
}

function evaluate(expr) {
  try {
    expr = expr.replace(/π/g, Math.PI);
    if (angleMode === "DEG") {
      expr = expr.replace(/sin\(([^)]+)\)/g, (_, angle) => `Math.sin(${angle}*Math.PI/180)`);
      expr = expr.replace(/cos\(([^)]+)\)/g, (_, angle) => `Math.cos(${angle}*Math.PI/180)`);
      expr = expr.replace(/tan\(([^)]+)\)/g, (_, angle) => `Math.tan(${angle}*Math.PI/180)`);
      expr = expr.replace(/asin\(([^)]+)\)/g, (_, val) => `(180/Math.PI*Math.asin(${val}))`);
      expr = expr.replace(/acos\(([^)]+)\)/g, (_, val) => `(180/Math.PI*Math.acos(${val}))`);
      expr = expr.replace(/atan\(([^)]+)\)/g, (_, val) => `(180/Math.PI*Math.atan(${val}))`);
    }
    expr = expr.replace(/ln\(/g, "Math.log(");
    expr = expr.replace(/log\(/g, "Math.log10(");
    expr = expr.replace(/√/g, "Math.sqrt");
    expr = expr.replace(/exp\(/g, "Math.exp(");
    expr = expr.replace(/([0-9]+)!/g, (_, n) => {
      let f = 1;
      for (let i = 1; i <= parseInt(n); i++) f *= i;
      return f;
    });
    return eval(expr);
  } catch {
    return "Erreur";
  }
}

function press(val) {
  if (val === "=") {
    display.textContent = evaluate(display.textContent);
  } else if (val === "DEG↔RAD") {
    angleMode = angleMode === "DEG" ? "RAD" : "DEG";
  } else {
    if (display.textContent === "0" || display.textContent === "Erreur") {
      display.textContent = val;
    } else {
      display.textContent += val;
    }
  }
}

function shareApp() {
  if (navigator.share) {
    navigator.share({
      title: "HT CALCULATOR",
      text: "Essaie cette superbe calculatrice !",
      url: window.location.href
    });
  } else {
    alert("Le partage n'est pas supporté sur ce navigateur.");
  }
}

function toggleOrientation() {
  if (screen.orientation) {
    screen.orientation.lock(screen.orientation.type.includes("portrait") ? "landscape" : "portrait").catch(console.error);
  }
}

window.onload = () => {
  const baseDiv = document.getElementById("buttons-base");
  const sciDiv = document.getElementById("buttons-scientifique");
  baseButtons.forEach(b => {
    const btn = document.createElement("button");
    btn.textContent = b;
    btn.onclick = () => press(b);
    baseDiv.appendChild(btn);
  });
  sciButtons.forEach(b => {
    const btn = document.createElement("button");
    btn.textContent = b;
    btn.onclick = () => press(b);
    sciDiv.appendChild(btn);
  });
}